firstInital='1'
secondInital='0'
print(firstInital + firstInital + firstInital + firstInital + firstInital)
print("  " + firstInital + ' ')
print("  " + firstInital + ' ')
print("  " + firstInital + '  ' + firstInital)
print("  " + firstInital+firstInital+firstInital+firstInital)