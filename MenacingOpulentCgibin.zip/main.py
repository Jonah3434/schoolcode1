#Jonah Belttari
'''
Nested ifs Notes
Monday, 1/6/2020
'''
school = str(input("What is your homeschool? "))
if school == "Salem" or school == "salem":
 grade = int(input("What grade are you in ? "))
 if grade == 9:
   print("You are a freshman at Salem. ")
 if grade == 10:
   print("You are a sophemore at Salem. ")
 if grade == 11:
   print("You are a junior at Salem. ")
 if grade == 12:
     print("You are a senior at Salem. ")
elif school == "Canton" or school == "canton":
 grade = int(input("What grade are you in ? "))
 if grade == 9:
   print("You are a freshman at Canton. ")
 if grade == 10:
   print("You are a sophemore at Canton. ")
 if grade == 11:
   print("You are a junior at canton. ")
 if grade == 12:
     print("You are a senior at Canton. ")
elif school == "Plymouth" or school == "plymouth":
 grade = int(input("What grade are you in ? "))
 if grade == 9:
   print("You are a freshman at Plymouth. ")
 if grade == 10:
   print("You are a sophemore at Plymouth. ")
 if grade == 11:
   print("You are a junior at Plymouth. ")
 if grade == 12:
     print("You are a senior at Plymouth. ")
